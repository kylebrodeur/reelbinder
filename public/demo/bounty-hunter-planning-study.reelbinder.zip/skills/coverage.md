---
id: coverage
title: Coverage
---

Setup {{shot.setup}} [{{shot.coverageSize}}] · {{shot.durationSec}}s
Camera: {{camera}}
Move: {{movement}}
Screen direction: {{direction}}
Time: {{time}}
Location: {{shot.location}}
Lighting stays: {{shot.lighting}}
