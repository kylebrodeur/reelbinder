---
id: veo
title: Veo 3
---

{{shot.durationSec}}-second shot. Photoreal, continuous motion, no morphing faces. Spoken dialogue only if named. No subtitles.
