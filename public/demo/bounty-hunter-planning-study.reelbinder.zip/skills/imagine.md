---
id: imagine
title: Imagine
---

Animate this shot for {{shot.durationSec}} seconds as a photoreal cinematic clip. Honor the world lock. If this continues from a still, the first frame is that still.
