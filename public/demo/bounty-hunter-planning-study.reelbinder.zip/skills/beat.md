---
id: beat
title: This beat
---

THIS BEAT — only these events may change the world
{{events}}
Action: {{shot.action}}
{{dialogue}}
{{notes}}
{{annot}}
