---
id: continuity
title: Continuity
---

Continuous physical motion. Same wardrobe, faces, weather, and color grade the whole clip. No jump cuts, no morphing, no extra people, no on-screen text, no subtitles, no watermark, no captions.
