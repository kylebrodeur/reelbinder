---
id: western
title: Western
---

Wardrobe and faces stay locked to the production book. Dust in the air. Candle practicals only. The Bounty Hunter never smiles and never speaks. Do not modernize the room.
