---
id: world
title: World lock
---

WORLD LOCK (persists for the whole film — do not change unless an event names it)
Place: {{world.place}}
Lighting: {{world.lighting}}
Ambience: {{world.ambience}}
Laws: {{world.laws}}
Style: {{style}}
