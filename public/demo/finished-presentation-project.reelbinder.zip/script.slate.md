---
title: The Bounty Hunter — V07 presentation copy (sound baked; history omitted)
logline: Afternoon in Crusty Rusty's. A drunk named Noodles buys a round. A silent man in a dark coat walks in, and the bartender starts a yarn. Three minutes. One room.
style: photoreal western short, 35mm anamorphic, dusty afternoon interior, candle practicals, filmic grain, no subtitles, no captions
target: imagine
cut: /api/cinema/assets/g1b_v07_presentation_01_48613faebbf5/content
---

# World

Place: Crusty Rusty's Tavern, wooden ashy saloon, long bar, swinging doors, back corner table
Lighting: candlelight and oil-lamp practicals, smoke in the air, warm tungsten, tanned skin, no modern fixtures
Ambience: quiet bar, glass, a chair scrape, the swing of doors. No score under the entrance. A low guitar only if credits are still rolling.
Laws: Gravity like Earth. Faces, wardrobe, and the tavern layout stay locked to the overhead (Noodles at 1, Rusty at 2, Bounty Hunter home at 3). The Bounty Hunter never speaks and never smiles. Rusty stays behind the bar unless he walks to the well. Afternoon interior. Camera is third-person cinematic.

# Cast

## Noodles
Also: Nino, Nino Noodles Sullivan, NOODLES
Look: 30s white man, thinning hair, tan jacket, blue shirt, dusty vest, neck bandana, drunk but precise
Voice: slurred, searching, curious
Start: seated at the bar, stage left of the bartender, facing the rail

## Rusty
Also: Crusty Rusty, CRUSTY, Crusty
Look: 50s bartender, white dress shirt, dark vest, armbands, apron, washcloth, large cross necklace on a leather string
Voice: slow Texas drawl, storytelling, a slight stutter on the first drink line
Start: behind the bar, drying a tankard

## The Bounty Hunter
Also: BH, Bounty Hunter, the bounty hunter
Look: tall silent man, dark trench coat, green shirt, brown vest, dark brown cowboy hat, holstered gun, almost John Wayne then William Holden then Clint Eastwood
Voice: does not speak in this scene
Start: off, about to enter through the swinging doors

# Skills

## Western
Wardrobe and faces stay locked to the production book. Dust in the air. Candle practicals only. The Bounty Hunter never smiles and never speaks. Do not modernize the room.

## Western
Wardrobe and faces stay locked to the production book. Dust in the air. Candle practicals only. The Bounty Hunter never smiles and never speaks. Do not modernize the room.

# Script

## INT. C[[cast:Behind the bar. Cross necklace always visible. Stutter on “t-t-take.”]]RUSTY[[/]] RUSTY'S TAVERN - AFTERNOON {#bh_sc_tavern}

Candlelight and smoke fill the [[lock]]wooden, ashy tavern[[/]]. Tan faces, sun-dried. Tan leather garb. A few [[extras]]poor alcoholics[[/]]. {#bh_a_smoke}

^ 1A [MS] #red
from: bh_a_smoke
to: bh_a_cigar
title: Tavern business
camera: medium
Master of the room. Holds under everything else — this is why the line runs the page.

A [[extras]]DRUNK CAMEO[[/]] flirts with a [[extras]]SULTRY WOMAN[[/]]. He extends a closed palm. Opens. There's a [[prop]]coin[[/]]. She is not impressed. {#bh_a_cameo}

NINO "[[cast:At the bar the whole open. Coin flick must read. Wardrobe lock: tan jacket, blue shirt, dusty vest, bandana.]]NOODLES[[/]]" SULLIVAN (30s) sits alone at the bar. The type of fellow drunk enough to coin the name and crazed enough to still accept it when sober. {#bh_a_noodles_sit}

^ 1E [MS] #ink
from: bh_a_noodles_sit
to: bh_dlg_noodles_1
title: Noodles at the rail
camera: medium
Camera remains on the bottom/front side of the source overhead and holds Noodles through his line.

The bartender, CRUSTY RUSTY (50s), dries a tankard. A large [[prop:hero]]cross necklace[[/]] hangs around his neck. {#bh_a_rusty_dry}

^ 1EE [MS] #blue
from: bh_a_rusty_dry
to: bh_dlg_rusty_1
title: Rusty dries a tankard
camera: medium
Rusty remains behind the east bar. Cross necklace must read.

NOODLES {#bh_ch_noodles_1}
I'll take... yea... I'll... I'll take
another... {#bh_dlg_noodles_1}

^ 1F [OTS] #green
from: bh_ch_noodles_1
to: bh_a_coin
title: The round
camera: over-the-shoulder
Noodles is the screen-left foreground shoulder; Rusty remains behind the east bar on screen right.

RUSTY {#bh_ch_rusty_1}
And I'll t-t-take another as well. {#bh_dlg_rusty_1}

He gives the man his famous crusty smile as he extends his hand. Noodles flicks a [[prop]]coin[[/]] into the man's palm, perfectly, with all the random precision of a drunk. {#bh_a_coin}

As Rusty leaves to refill the drink, we HEAR the [[sound]]SWING of bar doors[[/]] opening. {#bh_a_doors}

^ 1H [LS] #brown
from: bh_a_doors
to: bh_a_enter
title: The doors
camera: wide
Interior camera faces the single centered south entrance. Start before the Hunter is visible: hold the centered doors and Rusty behind the east bar; sound of the swing first.

A MAN enters--and it's not just any man, not just any entrance. He's [[lock]]THE BOUNTY HUNTER[[/]]. {#bh_a_enter}

[[cam:tracking]]He strolls to the bar[[/]], slow and silent like the roll of tumbleweed. [[no]]No one else moves.[[/]] {#bh_a_stroll}

^ 1J [MS] #plum
from: bh_a_stroll
to: bh_a_stroll
title: Tumbleweed to the bar
camera: medium
movement: tracking
Bounty Hunter, Noodles and Rusty hold distinct left-to-right positions while he approaches the rail.

[[eyeline:Rusty]]His eyes meet Rusty's[[/]]. He slides a [[prop]]coin[[/]] across the bar, and in tacit unison, the bartender pours a [[prop]]glass of whiskey[[/]]. {#bh_a_eyes}

^ 1K [ECU] #red
from: bh_a_eyes
to: bh_a_eyes
title: Bounty Hunter eyes
camera: extreme-close-up
One instant only: an extreme close-up of the Bounty Hunter's eyes beginning the stare-down.

^ 1L [ECU] #blue
from: bh_a_eyes
to: bh_a_eyes
title: Rusty eyes
camera: extreme-close-up
One instant only: Rusty's extreme close-up answers the stare-down from behind the bar.

^ 1M [Insert] #ink
from: bh_a_eyes
to: bh_a_eyes
title: The coin
camera: insert
One instant only: Bounty Hunter ownership of the single coin is explicit.

^ 1N [Insert] #brown
from: bh_a_eyes
to: bh_a_eyes
title: Rusty's pour
camera: insert
One instant only: the bottle and pouring hand enter from screen right; the glass stays on the customer side.

^ 1NN [2S] #plum
from: bh_a_eyes
to: bh_a_eyes
title: Whiskey across the bar
camera: medium
One instant only: the rail visibly separates Rusty from the customer-side Bounty Hunter.

[[hold]]He then tumbleweeds to his corner[[/]] in the back of the bar. {#bh_a_corner}

^ 1Q [OTS] #blue
from: bh_a_corner
to: bh_a_corner
title: To the corner
camera: over-the-shoulder
movement: tracking
Noodles holds the near-right foreground while the Bounty Hunter moves toward the north-west back corner.

NOODLES {#bh_ch_noodles_2}
Who the... who's that? {#bh_dlg_noodles_2}

^ 1R [OTS] #green
from: bh_ch_noodles_2
to: bh_dlg_rusty_3
title: We call him The Bounty Hunter
camera: over-the-shoulder
Noodles stays screen left in the near shoulder; Rusty stays behind the east bar.

RUSTY {#bh_ch_rusty_2}
Well, around here, we call him The Bounty
Hunter. {#bh_dlg_rusty_2}

Noodles wants more. {#bh_a_wants}

^ 1U [OTS] #brown
from: bh_a_wants
to: bh_a_cigar
title: Cigar in the dark
camera: over-the-shoulder
Hold under the yarn. This is the overlapping coverage that lining was invented for.

[[cast]]RUSTY[[/]] (CONT'D) {#bh_ch_rusty_3}
His story's a long one, and in most parts
a mystery. Some folks say he claimed his
first bounty when he was just thirteen
years young... Others say he once killed
three men with one bullet... {#bh_dlg_rusty_3}

(beat) {#bh_p_beat}

[[beat:swig]]...and no gun. Noodles swigs his beer[[/]], perhaps gulping more deliberately than usual. {#bh_a_nogun}

In the back, The Bounty Hunter blazes on his [[prop]]cigar[[/]]. [[phys]]Smoke hangs in the lamp light.[[/]] {#bh_a_cigar}
