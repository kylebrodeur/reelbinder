# The Bounty Hunter — ReelBinder finished presentation study

This is a media-light presentation Project. It opens in ReelBinder immediately with the screenplay, production planning, floor plan and accepted V07 source-trim timeline. The approved film media stays offline until you explicitly choose **Download media and relink** in Render.

The finished film bytes, provider records, contact sheets and rejected takes are excluded from this archive. Media is delivered only from the verified public download mirror described in the published descriptor.

Adapted from The Bounty Hunter by Ministry of Cinema. Screenplay by Bradley Weatherholt. Film and production material rights belong to Kyle Brodeur; the software MIT license does not license these materials.

Known film imperfections: some Rusty dialogue-sync and entrance-transition issues remain in the accepted V07 render.
