# The Bounty Hunter — ReelBinder finished presentation study (locked final cut)

This is a media-light presentation Project. It opens in ReelBinder immediately with the screenplay, production planning, floor plan and the locked 55.6-second final cut arranged as 17 picture excerpts. Music and the Rusty voice-over are baked into the film render; the approved film media stays offline until you explicitly choose **Download media and relink** in Render.

The opening title cards are baked into the film picture, not represented as live project text.

The finished film bytes, provider records, contact sheets and rejected takes are excluded from this archive. Media is delivered only from the verified public download mirror described in the published descriptor.

Adapted from "The Bounty Hunter" by Ministry of Cinema, screenplay by Bradley Weatherholt. Film and production material rights belong to Kyle Brodeur; the software MIT license does not license these materials.
